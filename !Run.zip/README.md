# Nighttweaks - The Ultimate Discord Selfbot

Nighttweaks is a powerful Discord selfbot that enhances your Discord experience with a wide range of useful commands. Whether you want to automate tasks, customize your messages, or simply have more control over your Discord client, Nighttweaks has got you covered.

## Commands

### /about
Display detailed information about the Nighttweaks selfbot, including its version and creator.

### /anti
Enable or disable anti-raid and anti-spam features for your server to maintain a secure and spam-free environment.

### /block
Block messages or mentions from specific users, giving you control over your message feed.

### /download
Download files and media directly from Discord channels for easy access to shared content.

### /embed
Create beautifully formatted embed messages with ease, allowing you to design eye-catching messages.

### /findviolations
Find and report potential rule violations within your server by scanning messages for suspicious activity.

### /hello
Get a friendly greeting from Nighttweaks to brighten your day!

### /help
Show a list of available commands along with detailed descriptions (you're looking at it right now).

### /killlist
Manage your custom "kill list" for blocking users who annoy you, helping you maintain a peaceful server experience.

### /mccolor
Generate Minecraft color codes for your text and send it with color on Discord. Choose from a variety of colors, such as §1 dark blue and §2 dark green, to add a unique touch to your messages.

### /purge
Quickly delete multiple messages in a channel, making it easier to clean up clutter and maintain a tidy chat environment.

### /status
Set a custom status message for your Discord profile to let others know what you're up to or express your mood.

### /unblock
Unblock previously blocked users and allow their messages and mentions, ensuring you can undo any accidental blocks.

## Getting Started

1. Make sure you have Nighttweaks added as a selfbot to your Discord client.
2. Open a chat window or server where you want to use Nighttweaks.
3. Type one of the commands listed above to unleash the power of Nighttweaks!

## Important Note

Please use Nighttweaks responsibly and ensure it complies with Discord's Terms of Service and your server's rules. Selfbots can be a fun addition to your Discord experience, but misuse may result in consequences.

Get ready to supercharge your Discord experience with Nighttweaks! Enjoy the convenience and customization it offers while interacting with your friends and communities in style.

Happy tweaking!
